<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0"/> 
    	<meta name="description" content="">
        <title>Compare Tree || Quote</title>
        <link href="https://fonts.googleapis.com/css?family=Lato:300,300i,400,400i,700,700i,900,900i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet"> 
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.theme.min.css">
        <link href="<?= base_url();?>assets/css/bootstrap.min.css" type="text/css" rel="stylesheet" media="all">
        <link href="<?= base_url();?>assets/css/main.css" type="text/css" rel="stylesheet" media="all">
        <link href="<?= base_url();?>assets/css/font-awesome.min.css" rel="stylesheet" type="text/css" /> 
		<script type="text/javascript" async defer src="http://code.jquery.com/jquery-1.7.2.min.js"></script>
        <script type="text/javascript">
		var baseUrl = '<?= base_url();?>index.php';	
			
		</script>
</head><!--/head-->
